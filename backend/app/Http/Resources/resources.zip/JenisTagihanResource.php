<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class JenisTagihanResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id'=>$this->id,
            'nama'=>$this->nama,
            'jatuh_tempo'=>$this->jatuh_tempo,
            'jumlah'=>$this->jumlah,
            'branch_id'=>$this->branch_id
        ];
    }
}
